import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.DefaultCaret;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.stream.Stream;

public class CollaborativeEditorUI extends JFrame {
    private JTextArea textArea;
    private JList<String> activeUsersList;
    private JLabel editorCodeLabel;
    private JLabel viewerCodeLabel;
    private JLabel statusLabel;
    private File currentFile;
    private final UndoManager undoManager = new UndoManager();

    public CollaborativeEditorUI(File file) {
        this.currentFile = file;
        setTitle("Collaborative Plain Text Editor - " + file.getName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem saveAsItem = new JMenuItem("Save As...");
        JMenuItem exitItem = new JMenuItem("Exit");
        saveItem.addActionListener(e -> saveFile(false));
        saveAsItem.addActionListener(e -> saveFile(true));
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(saveItem);
        fileMenu.add(saveAsItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu editMenu = new JMenu("Edit");
        JMenuItem undoItem = new JMenuItem("Undo");
        JMenuItem redoItem = new JMenuItem("Redo");
        undoItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK));
        redoItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK));
        undoItem.addActionListener(e -> {
            try { if (undoManager.canUndo()) undoManager.undo(); }
            catch (CannotUndoException ex) {}
        });
        redoItem.addActionListener(e -> {
            try { if (undoManager.canRedo()) undoManager.redo(); }
            catch (CannotRedoException ex) {}
        });
        editMenu.add(undoItem);
        editMenu.add(redoItem);

        JMenu collabMenu = new JMenu("Collaboration");
        JMenuItem joinSessionItem = new JMenuItem("Join Session...");
        JMenuItem viewCodesItem = new JMenuItem("View Shareable Codes");
        viewCodesItem.setEnabled(false);
        collabMenu.add(joinSessionItem);
        collabMenu.add(viewCodesItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(collabMenu);
        setJMenuBar(menuBar);

        // Text Area
        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane textScroll = new JScrollPane(textArea);
        DefaultCaret caret = (DefaultCaret) textArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        // Hook up UndoManager
        textArea.getDocument().addUndoableEditListener(new UndoableEditListener() {
            @Override
            public void undoableEditHappened(UndoableEditEvent e) {
                undoManager.addEdit(e.getEdit());
            }
        });

        // Sidebar (users & codes)
        JPanel sidebar = new JPanel(new BorderLayout(10, 10));
        sidebar.setBorder(new EmptyBorder(10, 10, 10, 10));
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.add(new JLabel("Active Users"), BorderLayout.NORTH);
        activeUsersList = new JList<>(new DefaultListModel<>());
        sidebar.add(new JScrollPane(activeUsersList), BorderLayout.CENTER);
        JPanel codesPanel = new JPanel(new GridLayout(2,1,5,5));
        editorCodeLabel = new JLabel("Editor Code: N/A");
        viewerCodeLabel = new JLabel("Viewer Code: N/A");
        codesPanel.add(editorCodeLabel);
        codesPanel.add(viewerCodeLabel);
        sidebar.add(codesPanel, BorderLayout.SOUTH);

        // Status Bar
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(new EmptyBorder(5,10,5,10));
        statusLabel = new JLabel("Disconnected | Role: Viewer | No changes");
        statusBar.add(statusLabel);

        // Layout
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(textScroll, BorderLayout.CENTER);
        getContentPane().add(sidebar, BorderLayout.EAST);
        getContentPane().add(statusBar, BorderLayout.SOUTH);

        // Load file content
        loadFile();

        // Actions
        joinSessionItem.addActionListener(e -> joinSession(viewCodesItem));
        viewCodesItem.addActionListener(e -> showCodesDialog());
    }

    private void loadFile() {
        try {
            String content = new String(Files.readAllBytes(currentFile.toPath()));
            textArea.setText(content);
            undoManager.discardAllEdits();
        } catch (IOException e) {
            textArea.setText("");
        }
    }

    private void saveFile(boolean saveAs) {
        try {
            if (saveAs) {
                JFileChooser chooser = new JFileChooser();
                chooser.setSelectedFile(currentFile);
                if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    currentFile = chooser.getSelectedFile();
                    setTitle("Collaborative Plain Text Editor - " + currentFile.getName());
                } else {
                    return;
                }
            }
            Files.write(currentFile.toPath(), textArea.getText().getBytes());
            statusLabel.setText("Saved to " + currentFile.getName());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage());
        }
    }

    private void joinSession(JMenuItem viewCodesItem) {
        String code = JOptionPane.showInputDialog(this, "Enter Session Code:", "Join Collaboration Session", JOptionPane.PLAIN_MESSAGE);
        if (code != null && !code.trim().isEmpty()) {
            statusLabel.setText("Connected | Role: Editor | No changes");
            viewCodesItem.setEnabled(true);
            editorCodeLabel.setText("Editor Code: " + generateCode());
            viewerCodeLabel.setText("Viewer Code: " + generateCode());
        }
    }

    private void showCodesDialog() {
        JOptionPane.showMessageDialog(this,
                editorCodeLabel.getText() + "\n" + viewerCodeLabel.getText(),
                "Shareable Codes", JOptionPane.INFORMATION_MESSAGE);
    }

    private String generateCode() {
        return (Math.random() < 0.5 ? "EDT-" : "VWR-") + (int)(Math.random()*9000+1000);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Create docs directory if missing
            File docsDir = new File("docs");
            if (!docsDir.exists()) docsDir.mkdir();

            // List existing .txt files
            String[] files = docsDir.list((dir, name) -> name.endsWith(".txt"));
            String selection = (String) JOptionPane.showInputDialog(
                    null, "Select or create a document:", "Open Document",
                    JOptionPane.PLAIN_MESSAGE, null,
                    Stream.concat(
                            Arrays.stream(files),
                            Stream.of("<Create New File>")
                    ).toArray(), null);

            File selectedFile;
            if ("<Create New File>".equals(selection) || selection == null) {
                String name = JOptionPane.showInputDialog(null, "Enter new file name (with .txt):", "New Document", JOptionPane.PLAIN_MESSAGE);
                if (name == null || !name.endsWith(".txt")) {
                    return; // cancel or invalid
                }
                selectedFile = new File(docsDir, name);
                try { selectedFile.createNewFile(); } catch (IOException e) { /* ignore */ }
            } else {
                selectedFile = new File(docsDir, selection);
            }

            CollaborativeEditorUI editor = new CollaborativeEditorUI(selectedFile);
            editor.setVisible(true);
        });
    }
}
