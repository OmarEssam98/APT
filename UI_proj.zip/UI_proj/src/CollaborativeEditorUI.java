import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CollaborativeEditorUI extends JFrame {
    private JTextArea textArea;
    private JList<String> activeUsersList;
    private JLabel editorCodeLabel;
    private JLabel viewerCodeLabel;
    private JLabel statusLabel;

    public CollaborativeEditorUI() {
        setTitle("Collaborative Plain Text Editor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem importItem = new JMenuItem("Import File...");
        JMenuItem exportItem = new JMenuItem("Export File...");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(importItem);
        fileMenu.add(exportItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu editMenu = new JMenu("Edit");
        JMenuItem undoItem = new JMenuItem("Undo");
        JMenuItem redoItem = new JMenuItem("Redo");
        editMenu.add(undoItem);
        editMenu.add(redoItem);

        JMenu collabMenu = new JMenu("Collaboration");
        JMenuItem joinSessionItem = new JMenuItem("Join Session...");
        JMenuItem viewCodesItem = new JMenuItem("View Shareable Codes");
        viewCodesItem.setEnabled(false);
        collabMenu.add(joinSessionItem);
        collabMenu.add(viewCodesItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(collabMenu);
        setJMenuBar(menuBar);

        // Main Text Area
        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane textScroll = new JScrollPane(textArea);
        DefaultCaret caret = (DefaultCaret) textArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BorderLayout(10, 10));
        sidebar.setBorder(new EmptyBorder(10, 10, 10, 10));
        sidebar.setPreferredSize(new Dimension(200, 0));

        JLabel usersLabel = new JLabel("Active Users");
        activeUsersList = new JList<>(new DefaultListModel<>());
        JScrollPane usersScroll = new JScrollPane(activeUsersList);

        JPanel codesPanel = new JPanel();
        codesPanel.setLayout(new GridLayout(2, 1, 5, 5));
        editorCodeLabel = new JLabel("Editor Code: N/A");
        viewerCodeLabel = new JLabel("Viewer Code: N/A");
        codesPanel.add(editorCodeLabel);
        codesPanel.add(viewerCodeLabel);

        sidebar.add(usersLabel, BorderLayout.NORTH);
        sidebar.add(usersScroll, BorderLayout.CENTER);
        sidebar.add(codesPanel, BorderLayout.SOUTH);

        // Status Bar
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(new EmptyBorder(5, 10, 5, 10));
        statusLabel = new JLabel("Disconnected | Role: Viewer | No changes");
        statusBar.add(statusLabel);

        // Layout
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(textScroll, BorderLayout.CENTER);
        getContentPane().add(sidebar, BorderLayout.EAST);
        getContentPane().add(statusBar, BorderLayout.SOUTH);

        // Actions
        joinSessionItem.addActionListener(e -> joinSession(viewCodesItem));
        viewCodesItem.addActionListener(e -> showCodesDialog());
    }

    private void joinSession(JMenuItem viewCodesItem) {
        String code = JOptionPane.showInputDialog(this, "Enter Session Code:", "Join Collaboration Session", JOptionPane.PLAIN_MESSAGE);
        if (code != null && !code.trim().isEmpty()) {
            // TODO: Integrate collaboration logic
            statusLabel.setText("Connected | Role: Editor | No changes");
            viewCodesItem.setEnabled(true);
            editorCodeLabel.setText("Editor Code: " + generateEditorCode());
            viewerCodeLabel.setText("Viewer Code: " + generateViewerCode());
        }
    }

    private void showCodesDialog() {
        JOptionPane.showMessageDialog(this,
                editorCodeLabel.getText() + "\n" + viewerCodeLabel.getText(),
                "Shareable Codes", JOptionPane.INFORMATION_MESSAGE);
    }

    private String generateEditorCode() {
        return "EDT-" + (int)(Math.random() * 9000 + 1000);
    }

    private String generateViewerCode() {
        return "VWR-" + (int)(Math.random() * 9000 + 1000);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CollaborativeEditorUI ui = new CollaborativeEditorUI();
            ui.setVisible(true);
        });
    }
}
